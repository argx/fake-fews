I've been messing around with this extension a bit, not even sure what it does right now.

To run:
Go to chrome://extensions/
Make sure developer mode is enabled
Select "Load unpacked extension"
Open this folder
You should see a "Hello World" along with the other extensions

When you go to www.reddit.com and click on the icon, something should happen maybe if you're lucky.